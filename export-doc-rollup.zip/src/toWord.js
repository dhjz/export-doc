export function toWrod() {
  const a = {b: 123}
  let c = a?.b || 22
  let d = (str) => str.trim()
  console.log(c);
  console.log(d);
  console.log('toWrod...');
}