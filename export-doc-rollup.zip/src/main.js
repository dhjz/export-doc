import { toWrod } from './toWord'

const ExportDoc = {
  toWrod
}

export default ExportDoc

