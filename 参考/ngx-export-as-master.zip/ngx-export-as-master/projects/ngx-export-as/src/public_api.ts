/*
 * Public API Surface of ngx-export-as
 */

export * from './lib/export-as.service';
export * from './lib/export-as-config.model';
export * from './lib/export-as.module';
